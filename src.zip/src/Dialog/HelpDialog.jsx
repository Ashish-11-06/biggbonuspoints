import React from 'react'
import { Dialog, Portal } from 'react-native-paper'

const HelpDialog = ({visible,onDismiss}) => {
  return (
   <Portal>
    <Dialog visible={visible} onDismiss={onDismiss}>
      <Dialog.Title>Need Help?</Dialog.Title>
      <Dialog.Content>
        <Paragraph>
          If you are facing any issues, please contact our customer support.
        </Paragraph>
      </Dialog.Content>
      <Dialog.Actions>
        <Button>Close</Button>
      </Dialog.Actions>
      </Dialog>
   </Portal>
  )
}

export default HelpDialog
